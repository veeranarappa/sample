import React from "react";

class One extends React.Component{
    render(){
        return(
            <div>
                <h1>This is One Heading </h1>
                <p> With this digital technology evolution, there is an increased demand for new technologies to be implemented by various businesses. Some of the most recent technology trends reported to impact the FinTech industry include Blockchain and Distributed Ledger; Programming; Machine Learning, AI, Big Data and Deep Learning; and Cybersecurity. Such rapid changes in digital technologies inevitably influence the growing demand from employers in seeking employees with specific skill sets. The Fintech industry is evolving quickly and it has supported the financial sector in overcoming various challenges. Still a fresh and expanding industry, the experience that you would need in the industry spans across a range of engineering and technical skills</p>
    
            </div>
        )
    }
}

export default One;