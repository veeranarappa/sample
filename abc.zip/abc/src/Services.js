import React from "react";

function Services(){
    return(
        <div>
            <h3> This is Services Component</h3>
        </div>
    )
}
export default Services;