

function Function1(props){
    if (props.show){
        return  null
    }
    else{
        return(
            <div>
                this is Function
            </div>
        )
    }
    
}

export default Function1;