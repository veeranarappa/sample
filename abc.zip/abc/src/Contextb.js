import React from 'react';
import Contextc from './Contextc'

function Contextb(props){
    return(
        <div>
            <h1> Hii B</h1>
            <Contextc></Contextc>
        </div>
    )
}

export default Contextb;